module.exports = {
  host: "localhost",
  user: "root",
  password: "Guziqian030121",
  database : "crowdfunding_db"
};